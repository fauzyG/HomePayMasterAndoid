package com.fauzy.homepay.model

/**
 * Created by Tisto on 3/11/2021.
 */
class Bank(
        var nama: String,
        var rekening: String,
        var penerima: String,
        var image: Int,
        var id: String = ""
)