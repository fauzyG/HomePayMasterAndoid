package com.fauzy.homepay.model.rajaongkir

import com.fauzy.homepay.model.ModelAlamat

class Cost {
    val value = ""
    val etd = ""
    val note = ""
}