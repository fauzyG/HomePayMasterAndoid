package com.fauzy.homepay.util

/**
 * Created by fauzy on 1/11/2021.
 */
object Config {
    const val baseUrl2 = "http://192.168.43.162/homepay/public/"
    const val productUrl = baseUrl2 + "storage/produk/"
}