package com.fauzy.homepay.util

/**
 * Created by fauzy on 2/2/2021.
 */
object ApiKey {
    const val key = "bc4d850f9cbafb899fbed2ac4db9428b"
}