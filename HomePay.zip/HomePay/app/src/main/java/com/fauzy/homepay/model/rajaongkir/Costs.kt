package com.fauzy.homepay.model.rajaongkir

import com.fauzy.homepay.model.ModelAlamat

class Costs {
    val service = ""
    val description = ""
    val cost = ArrayList<Cost>()
    var isActive = false
}