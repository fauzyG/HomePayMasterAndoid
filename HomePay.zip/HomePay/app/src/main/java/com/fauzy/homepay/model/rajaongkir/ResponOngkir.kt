package com.fauzy.homepay.model.rajaongkir

import com.fauzy.homepay.model.ModelAlamat

class ResponOngkir {
    val rajaongkir = Rajaongkir()

    class Rajaongkir{
        val results = ArrayList<Result>()
    }

}