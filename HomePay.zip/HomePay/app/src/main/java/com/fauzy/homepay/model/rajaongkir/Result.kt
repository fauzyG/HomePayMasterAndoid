package com.fauzy.homepay.model.rajaongkir

import com.fauzy.homepay.model.ModelAlamat

class Result {
    val name = ""
    val code = ""
    val costs = ArrayList<Costs>()
}